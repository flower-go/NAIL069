package cz.sokoban4j.simulation.actions.oop;

public enum EActionType {

	MOVE,
	PUSH,
	WALK,
	WALK_AND_PUSH,
	INVALID;
	
}
