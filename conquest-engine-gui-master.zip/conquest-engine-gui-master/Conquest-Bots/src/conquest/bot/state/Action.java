package conquest.bot.state;

public interface Action {
	void apply(GameState state);
}
