package conquest.bot.fight;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class FightUtils {

	public static final NumberFormat formatterChance = new DecimalFormat("#0.000000");
	public static final NumberFormat formatterNumber = new DecimalFormat("#000.000000");
	
}

