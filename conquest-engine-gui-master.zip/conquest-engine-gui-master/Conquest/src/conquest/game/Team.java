package conquest.game;

public enum Team {
	
	PLAYER_1,
	PLAYER_2,
	NEUTRAL;
			
}
