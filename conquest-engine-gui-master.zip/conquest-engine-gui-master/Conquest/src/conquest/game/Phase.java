package conquest.game;

public enum Phase {
	STARTING_REGIONS, PLACE_ARMIES, ATTACK_TRANSFER
}
