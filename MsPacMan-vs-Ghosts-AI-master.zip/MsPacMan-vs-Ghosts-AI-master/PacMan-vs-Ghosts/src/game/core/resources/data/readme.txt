a,b,c,d -> MAZES

Columns: NODE INDEX | X | Y | Neighbours UP | RIGHT | DOWN | LEFT | PillIndex | PowerPillIndex
                              -1 == n/a                             -1 == n/a   -1 == n/a