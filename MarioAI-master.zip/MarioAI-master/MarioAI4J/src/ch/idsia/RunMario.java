package ch.idsia;

import ch.idsia.benchmark.mario.MarioSimulator;

public class RunMario {

	public static void main(String[] args) {
		MarioSimulator.main(args);
	}
	
}
